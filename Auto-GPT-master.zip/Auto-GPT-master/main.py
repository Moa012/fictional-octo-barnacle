from scripts.main import main
